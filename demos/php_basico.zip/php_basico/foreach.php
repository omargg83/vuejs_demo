<?php 
$superHeroes = array('heroe1'=>'batman','heroe2'=>'superman','heroe3'=>'spiderman');

foreach ($superHeroes as $key => $value) {
    $var = $value;
    echo $var."<br>";
}

echo "<br>";

$arraySimple = array(1,2,3,4,5,6,7);
foreach ($arraySimple as $value) {
    $var2 = $value;
    echo $var2."<br>";
}

?>