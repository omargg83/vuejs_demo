<?php 
/*
==
===
!=
<>
<
>
<=
>=
<=>
??

&&
||
not
*/
$edad = 18;
$genero = 'm';
$peso = 80;
if($edad >= 18){
    if($genero == 'm' && $peso <= 100){
        echo "es mayor de edad y es masculino puede hacer servicio militar y tiene el peso adecuado";
    }else{
        echo "es mayor de edad pero no es hombre no hace servicio militar";
    }
}else{
    echo "no es mayor de edad";
}


?>