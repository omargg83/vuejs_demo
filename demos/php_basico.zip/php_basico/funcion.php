<?php 

function hola($nombre){
    echo "hola"." ".$nombre;
    echo "<br>";
}
hola("Maria");
hola("Arturo");
hola("Vanesa");
echo "<br>";

function suma($val1,$val2){
    // + * / -
    $res = $val1 + $val2;
    return $res;
}
$var1 = 50;
echo suma($var1,13);
?>