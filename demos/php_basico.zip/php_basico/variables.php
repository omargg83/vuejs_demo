<?php
// VARIABLES
$nombre = "Alberto"; 
$entero = 12;
$double = 12.3;
$bool = true;
echo $nombre;
echo '<br>';
$nombre = "Jorge";
echo $nombre;
echo '<br>';
// CONSTANTES
define("PI",3.1416);
echo PI;
// CONCATENACIONES
echo '<br>';
echo $nombre.' '.$entero;
echo '<br>';
echo "Hola como estas {$nombre}";
?> 