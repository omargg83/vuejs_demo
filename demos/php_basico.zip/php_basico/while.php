<?php 
$num = 1;
while ($num <= 10) {
    echo "Incrementando variable hasta que llege al numero 10: ".$num;
    echo "<br>";
    $num++;
}

?>