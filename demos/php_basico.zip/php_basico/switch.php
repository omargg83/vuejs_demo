<?php 
$dia = 'saturday';

switch($dia){
    case 'lunes':
    echo "El dia de hoy es {$dia}";
    break;
    case 'martes':
    echo "El dia de hoy es {$dia}";
    break;
    case 'miercoles':
    echo "El dia de hoy es {$dia}";
    break;
    case 'jueves':
    echo "El dia de hoy es {$dia}";
    break;
    case 'viernes':
    case 'sabado':
    case 'domingo':
    echo "El dia de hoy no se trabaja";
    break;
    default:
    echo "El dia no existe";
    break;
}

?>