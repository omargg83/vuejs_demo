<?php 
$array = array('valor1','valor2',56,true);
var_dump($array);
echo "<br>";
echo $array[3];
echo "<br>";
$varArray = array("valor1"=>"Alberto","valor2"=>"Roberto","valor3"=>345);
echo $varArray["valor1"];
?>