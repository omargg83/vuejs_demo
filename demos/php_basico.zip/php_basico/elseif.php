<?php 
$dia = 'viernes';

if($dia == 'lunes'){
    echo "El dia de hoy es {$dia}";
}else if($dia == 'martes'){
    echo "El dia de hoy es {$dia}";
}else if($dia == 'miercoles'){
    echo "El dia de hoy es {$dia}";
}else if($dia == 'jueves'){
    echo "El dia de hoy es {$dia}";
}else{
    echo "El dia de hoy es {$dia}";
}

?>