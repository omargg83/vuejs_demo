<?php 
$con = new mysqli('localhost','root','','crud');
?>